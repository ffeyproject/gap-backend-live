<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 05/09/19
 * Time: 12.56
 */

namespace common\models\ar;


class User extends \common\models\User
{

}