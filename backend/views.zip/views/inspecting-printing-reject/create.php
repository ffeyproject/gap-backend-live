<?php

/* @var $this yii\web\View */
/* @var $model common\models\ar\InspectingPrintingReject */
?>
<div class="inspecting-printing-reject-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
