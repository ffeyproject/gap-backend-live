<?php
/* @var $this yii\web\View */
/* @var $model common\models\ar\TrnWoMemo */
?>
<div class="trn-wo-memo-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
