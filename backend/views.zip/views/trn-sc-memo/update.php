<?php
/* @var $this yii\web\View */
/* @var $model common\models\ar\TrnScMemo */
?>

<div class="trn-sc-memo-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
