<?php
/* @var $this yii\web\View */
/* @var $model common\models\ar\TrnScGreige */
?>
<div class="trn-sc-greige-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
