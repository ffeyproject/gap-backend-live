<?php

/* @var $this yii\web\View */
/* @var $model common\models\ar\TrnScAgen */
?>
<div class="trn-sc-agen-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
