<?php
/* @var $this yii\web\View */
/* @var $model common\models\ar\InspectingDyeingReject */
?>
<div class="inspecting-dyeing-reject-create">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
